@extends('layouts.app')

@section('video')
	<div class="center-container">
		<div class="banner wthree">
			<div class="container">
				<div class="banner_top">
					<div class="col-md-6 col-sm-4 col-xs-4 logo">
						<h1><a href="index.html">Glorious<span>Restaurant</span></a></h1>
					</div>
					<div class="col-md-6 col-sm-8 col-xs-8 w3_menu">
						<div class="col-md-6 col-sm-5 col-xs-5 top-nav-text">
							<a class="page-scroll" href="#myModal2" data-toggle="modal" data-hover="LOGIN">LOGIN</a>
						</div>
						<div class="col-md-3 col-sm-4 col-xs-4 top-nav-text">
							<a class="page-scroll" href="#myModal3" data-toggle="modal" data-hover="LOGIN">REGISTER</a>
						</div>
						<div class="mobile-nav-button">
							<div class="mobile-nav-button__line"></div>
							<div class="mobile-nav-button__line"></div>
							<div class="mobile-nav-button__line"></div>
						</div>
						<nav class="mobile-menu">
							<ul>
								<li class="active"><a href="index.html">Home</a></li>
								<li><a href="#services" class="scroll">Services</a></li>
								<li><a href="#chefs" class="scroll">Our Chefs</a></li>
								<li><a href="#menu" class="scroll">Menu</a></li>
								<li><a href="#gallery" class="scroll">Gallery</a></li>
								<li><a href="#contact" class="scroll">Contact Us</a></li>
							</ul>
						</nav>
					</div>
					<div class="clearfix"> </div>
				</div>
				<!--Slider-->	
				<div class="col-md-7 callbacks_container">
					<ul class="rslides" id="slider3">
						<li>
							<div class="slider-info">
								<h3>Fresh Food Restaurant</h3>
								<p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
							</div>
						</li>
						<li>
							<div class="slider-info">
								 <h3>Welcome To Restaurant</h3>
								 <p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
							</div>
						</li>
						<li>
							<div class="slider-info">
								 <h3>Perfect Match For Your Restaurant</h3>
								 <p>Lorem ipsum dolor sit amet, consectetur sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
							</div>
						</li>
					</ul>
				</div>
				<!-- //Slider -->
				<!-- form -->
				<div class="col-md-5 callbacks_container form-w3l-agil3">
					<div class="book-form">
					<p>Reserve a table.</p>
					   <form action="#" method="post">
							<div class="form-time-w3layouts">
									<label><i class="fa fa-clock-o" aria-hidden="true"></i> Time :</label>
									<input type="text" id="timepicker" name="Time" class="timepicker form-control" value="Hrs:Min" required="">	
							</div>
							<div class="form-date-w3-agileits">
										<label><i class="fa fa-calendar" aria-hidden="true"></i> Date :</label>
											<input  id="datepicker1" name="Text" type="text" value="mm/dd/yyyy" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="">
										</div>
							<div class="form-left-agileits-w3layouts ">
									<label><i class="fa fa-users" aria-hidden="true"></i> No.of People :</label>
									<select class="form-control">
										<option>1 Person</option>
										<option>2 People</option>
										<option>3 People</option>
										<option>4 People</option>
										<option>5 People</option>
										<option>More</option>
									</select>
							</div>
							<div class="form-left-agileits-submit">
								  <input type="submit" value="Book a table">
							</div>
						</form>
					</div>
				</div>
				<div class="clearfix"> </div>
				<!-- //form -->
			</div>
		</div>
		<!-- modal -->
		<div class="modal about-modal w3-agileits fade" id="myModal2" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
					</div> 
					<div class="modal-body login-page "><!-- login-page -->     
						<div class="login-top sign-top">
							<div class="agileits-login">
							<h5>Login Here</h5>
							<form id="loginForm" action="" method="post">
                                                            <?php echo csrf_field();?>
								<input type="email" class="email {{ $errors->has('email') ? ' has-error' : '' }}" name="Email" placeholder="Email" value="{{ old('email') }}" required=""/>
								<input type="password" class="password {{ $errors->has('password') ? ' has-error' : '' }}" name="Password" placeholder="Password" required=""/>
								<div class="wthree-text"> 
									<ul> 
										<li>
											<label class="anim">
												<input type="checkbox" class="checkbox">
												<span> Remember me ?</span> 
											</label> 
										</li>
									</ul>
									<div class="clearfix"> </div>
								</div>  
								<div class="w3ls-submit"> 
                                                                    <input type="submit" value="LOGIN">  	
								</div>	
							</form>

							</div>  
						</div>
					</div>  
				</div> <!-- //login-page -->
			</div>
		</div>
		<!-- //modal --> 
		<!-- modal -->
		<div class="modal about-modal w3-agileits fade" id="myModal3" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
					</div> 
					<div class="modal-body login-page "><!-- login-page -->     
						<div class="login-top sign-top">
							<div class="agileits-login">
							<h5>Register Here</h5>
							<form action="#" method="post">
								<input type="text" name="Username" placeholder="Username" required=""/>
								<input type="email"  name="Email" placeholder="Email" required=""/>
								<input type="password" name="Password" placeholder="Password" required=""/>
								<input type="text" name="password" placeholder="Confirm Password" required="">
								<div class="wthree-text"> 
									<ul> 
										<li>
											<label class="anim">
												<input type="checkbox" class="checkbox">
												<span> I accept the terms of use</span> 
											</label> 
										</li>
									</ul>
									<div class="clearfix"> </div>
								</div>  
								<div class="w3ls-submit"> 
									<input type="submit" value="Register">  	
								</div>	
							</form>
							</div>  
						</div>
					</div>  
				</div> <!-- //login-page -->
			</div>
		</div>
		<!-- //modal --> 
	</div>
@stop
<!-- grids -->
@section('grids')
	<div class="col-md-6 about-grids-w3l">
		<div class="about-first-w3">
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/1.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/2.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/3.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="about-first-w3">
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/4.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/5.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 welcome-img">
				<img src="{{asset('assets/images/6.jpg')}}" class="img-responsive zoom-img" alt=""/>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="col-md-6 w3layouts_event_right">
		<h3>made with fresh  Ingredients</h3>
		<div class="slider">
			<div class="flexslider">
				<ul class="slides">
					<li>
						<div class="w3_event_right_grid">
							<div class="w3layouts_event_right_para">
								<p>Nam tempus lobortis sem non ornare. Curabitur dignissim interdum sem, et mollis lorem. 
									Mauris hendrerit, mi in aliquet egestas, nisi mi vestibulum turpis.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="w3_event_right_grid">
							<div class="w3layouts_event_right_para">
								<p>Nam tempus lobortis sem non ornare. Curabitur dignissim interdum sem, et mollis lorem. 
									Mauris hendrerit, mi in aliquet egestas, nisi mi vestibulum turpis.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="w3_event_right_grid">
							<div class="w3layouts_event_right_para">
								<p>Nam tempus lobortis sem non ornare. Curabitur dignissim interdum sem, et mollis lorem. 
									Mauris hendrerit, mi in aliquet egestas, nisi mi vestibulum turpis.</p>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="clearfix"> </div>
@stop        
<!-- //grids -->
@section('services')
<!-- services -->
	<div class="container">
		<div class="agile-heading">
			<h3 class="w3l-title">Our Services</h3>
		</div>
		<div class="wthree-services-grids">
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-cutlery" aria-hidden="true"></i>
						<h4>BEST COOKS</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-car" aria-hidden="true"></i>
						<h4>FREE PARKING</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-spoon" aria-hidden="true"></i>
						<h4>FRESH FOOD</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						<h4>Excellent</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="wthree-services-grids services-grids1">
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-money" aria-hidden="true"></i>
						<h4>Best Price</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-birthday-cake" aria-hidden="true"></i>
						<h4>BIRTHDAY PARTY</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-credit-card" aria-hidden="true"></i>
						<h4>Easy Payment</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="col-sm-3 wthree-services">
				<div class="wthree-services-grid">
					<div class="wthree-services-info">
						<i class="fa fa-bullhorn" aria-hidden="true"></i>
						<h4>Hotel Popular</h4>
						<div class="w3ls-border"> </div>
					</div>
					<div class="wthree-services-captn">
						<h4>Glorious</h4>
						<p>Aenean pulvinar ac enimet posuere tincidunt velit Utin tincidunt</p>
					</div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
@stop
<!-- //services -->
<!-- team -->
@section('team')
	<div class="container">
		<div class="agile-heading team-heading">
			<h3 class="w3l-title">Meet Our Chefs</h3>
		</div>
		<div class="agile-team-grids">
			<div class="col-sm-3 team-grid">
				<div class="flip-container">
					<div class="flipper">
						<div class="front">
							<img src="{{asset('assets/images/t1.jpg')}}" alt="" />
						</div>
						<div class="back">
							<h4>Peter Parker</h4>
							<p>Vestibulum </p>
							<div class="w3l-social">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3 team-grid">
				<div class="flip-container">
					<div class="flipper">
						<div class="front">
							<img src="{{asset('assets/images/t2.jpg')}}" alt="" />
						</div>
						<div class="back">
							<h4>Steven Wilson</h4>
							<p>Quisque vitae</p>
							<div class="w3l-social">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3 team-grid">
				<div class="flip-container">
					<div class="flipper">
						<div class="front">
							<img src="{{asset('assets/images/t3.jpg')}}" alt="" />
						</div>
						<div class="back">
							<h4>Johan Botha</h4>
							<p>Nulla molestie</p>
							<div class="w3l-social">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3 team-grid">
				<div class="flip-container">
					<div class="flipper">
						<div class="front">
							<img src="{{asset('assets/images/t4.jpg')}}" alt="" />
						</div>
						<div class="back">
							<h4>Mary Jane</h4>
							<p>Aliquam non</p>
							<div class="w3l-social">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- //team -->
@stop
<!-- menu-section -->
@section('menu-section')

	<h3 class="w3l-title">Menu</h3>
	<ul id="flexiselDemo1">	
		<li>
			<div class="w3layouts_banner_bottom_left">
				<img src="{{asset('assets/images/s1.jpg')}}" alt=" " class="img-responsive" />
				<h4>Noodles --- <span>$5</span></h4>
				<p>Morbi eu justo suscipit.</p>
			</div>
		</li>
		<li>
			<div class="w3layouts_banner_bottom_left">
				<img src="{{asset('assets/images/s2.jpg')}}" alt=" " class="img-responsive" />
				<h4>Ice-Cream --- <span>$7</span></h4>
				<p>Morbi eu justo suscipit.</p>
			</div>
		</li>
		<li>
			<div class="w3layouts_banner_bottom_left">
				<img src="{{asset('assets/images/s5.jpg')}}" alt=" " class="img-responsive" />
				<h4>Lemon Fruit --- <span>$3</span></h4>
				<p>Morbi eu justo suscipit.</p>
			</div>
		</li>
		<li>
			<div class="w3layouts_banner_bottom_left">
				<img src="{{asset('assets/images/s4.jpg')}}" alt=" " class="img-responsive" />
				<h4>SeaFood --- <span>$8</span></h4>
				<p>Morbi eu justo suscipit.</p>
			</div>
		</li>
		<li>
			<div class="w3layouts_banner_bottom_left">
				<img src="{{asset('assets/images/s3.jpg')}}" alt=" " class="img-responsive" />
				<h4>Breakfast Bun--- <span>$3</span></h4>
				<p>Morbi eu justo suscipit.</p>
			</div>
		</li>
	</ul>
<!-- //menu-section -->
@stop
<!-- cuisine-names -->
@section('cuisine-names')
	<div class="w3_cuisine_names_left w3l_cuisine_names_left">
		<h3>Egg Rolls ----- <span>$3</span></h3>
		<h3>Fried Shrimp ----- <span>$5</span></h3>
		<h3>Wrapped Chicken ----- <span>$7</span></h3>
		<h3>Hot and Sour Soup ----- <span>$4</span></h3>
		<h3>Chicken Soup ----- <span>$5</span></h3>
	</div>
	<div class="w3ls_cuisine_names_left">
		<img src="{{asset('assets/images/pri.png')}}" alt=" " class="img-responsive" />
	</div>
	<div class="w3_cuisine_names_left">
		<h3>Mushroom Chicken ----- <span>$4</span></h3>
		<h3>Kung pao Beef ----- <span>$7</span></h3>
		<h3>Garlic Shrimp ----- <span>$3</span></h3>
		<h3>Hot Been Curd ----- <span>$8</span></h3>
		<h3>Soft Drinks ----- <span>$5</span></h3>
	</div>
	<div class="clearfix"> </div>
@stop        

<!-- //cuisine-names -->
@section('testimonials')
<!-- testimonials -->

	<div class="container">
		<h3 class="w3l-title">Testimonials</h3>
		<div class="w3_testimonials_grids">
			<div class="col-md-4 col-sm-4 item w3_agileits_testimonials_grid">
				<img src="{{asset('assets/images/g1.jpg')}}" alt=" " class="img-responsive w3-main-img" />
				<img class="posi-w3l img-responsive" src="{{asset('assets/images/test1.jpg') }}" alt=" " />
				<div class="text-w3l">
					<h4>Rosy Alen</h4>
					<p>Donec quis turpis pellentesque justo pulvinar scelerisque placerat mattis enim.</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 item w3_agileits_testimonials_grid">
				<img src="{{asset('assets/images/g5.jpg') }}" alt=" " class="img-responsive w3-main-img" />
				<img class="posi-w3l img-responsive" src="{{asset('assets/images/test2.jpg') }}" alt=" " />
				<div class="text-w3l">
					<h4>Thomas Li</h4>
					<p>Donec quis turpis pellentesque justo pulvinar scelerisque placerat mattis enim.</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 item w3_agileits_testimonials_grid">
				<img src="{{asset('assets/images/g4.jpg') }}" alt=" " class="img-responsive w3-main-img" />
				<img class="posi-w3l img-responsive" src="{{asset('assets/images/test3.jpg') }}" alt=" " />
				<div class="text-w3l">
					<h4>Chrst pher</h4>
					<p>Donec quis turpis pellentesque justo pulvinar scelerisque placerat mattis enim.</p>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //testimonials -->
@stop
<!-- delicious-food -->
@section('delicious_food')
	<div class="container">
		<h3 class="w3l-title">Our Delicious Food</h3>
		<div class="agile_delicious_food_grids">
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g1.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g1.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g2.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g2.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g3.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g3.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g4.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g4.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g5.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g5.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g6.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g6.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g7.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g7.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g8.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g8.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="agile_delicious_food_grid">
				<a class="sb" href="{{asset('assets/images/g9.jpg') }}" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate.">
					<div class="view view-sixth">
						<img src="{{asset('assets/images/g9.jpg') }}" alt=" " class="img-responsive" />
						<div class="mask">
							<h4>Glorious</h4>
							<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
						</div>
					</div>
				</a>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //delicious-food -->
@stop
<!-- footer -->
@section('footer')
	<div class="container">
		<div class="agile-footer-grids">
			<div class="col-md-3 col-sm-6 col-xs-6 w3-agile-footer-grid">
				<div class="logo-2">
					<h2><a href="index.html">Glorious<span>Restaurant</span></a></h2>
				</div>
				<ul>
					<li>Lorem ipsum dolor sit,</li>
					<li>BD 2 Mars,</li>
					<li>N° 136</li>
					<li>Email</li>
					<li><a href="mailto:info@example.com">info@example.com</a></li>
					<li>Phone Number</li>
					<li>+123 456 7890</li>
				</ul>				
			</div>
			<div class="col-md-3 col-sm-6 col-xs-6 w3-agile-footer-grid">
				<h3>Opening Days</h3>
				<div class="col-md-5 col-sm-5 col-xs-5 agile-opening">
					<ul>
						<li>Monday </li>
						<li>Tuesday </li>
						<li>Wednesday </li>
						<li>Thursday </li>
						<li>Friday </li>
						<li>Saturday </li>
						<li>Sunday </li>
					</ul>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-6 agile-opening">
					<ul>
						<li>8am-10pm</li>
						<li>9am-10pm</li>
						<li>7am-11pm</li>
						<li>5am-11pm</li>
						<li>6am-12pm</li>
						<li>7am-12pm</li>
						<li>4am-12pm</li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 w3-agile-footer-grid grid-w3-1">
				<div class="contact-block-left">
					<form action="#" method="post">
						<input type="text" placeholder="Name" name="Name" required="">
						<input type="email" class="email" placeholder="Email" name="Email" required="">             
						<textarea placeholder="Message" name="message" required=""></textarea>
						<input type="submit" value="Send">
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- copyright -->
	<div class="copyright">
		<p>© 2017 Glorious . All Rights Reserved | Design by <a href="http://w3layouts.com/"> W3layouts</a> </p>
	</div>
	<!-- //copyright -->
        
<!-- //footer -->
<script type="text/javascript" src="{{asset('assets/js/jquery-2.1.4.min.js')}}"></script>
<script>
 var loginForm=$("#loginForm");
 loginForm.submit(function(e){
       e.preventDefault();
       var formData = loginForm.serialize();
     //var param={_token:$("input[name='_token']").val(),email:$("input[name='Email']").val(),password:$("input[name='Password']").val()};
       $.ajax({
        url:"{{route('logout')}}",
        data:formData,
        type:"post",
        success:function(data){
           console.log(data); 
        },
         error: function (data) {
            console.log(data);
        }
     });
   });    
</script>
@endsection

