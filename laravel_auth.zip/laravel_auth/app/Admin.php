<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
    public $table='admin';
    
    public static function do_login() {        
         $user_data = ['email' => 'suresh@gmail.com', 'password' => '123456'];
         
         dd(\Auth::guard('admin')->attempt($user_data));
    }
}
